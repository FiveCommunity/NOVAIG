
import Bullets from "/icons/bullets.svg";
import { useData } from "../hooks/useData";

export default function OthersInformations() {
  const { data } = useData();

  return (
    <div className="flex items-center gap-4 absolute top-5 right-5 ">
      
    </div>
  );
}
