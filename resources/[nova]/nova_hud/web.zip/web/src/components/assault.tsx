import AssaultIcon from "/images/assault.png";

export function Assault() {
  return <img src={AssaultIcon} className="w-[10.5rem]" />;
}
